<!-- 
<?php
// require_once("model.php");

// session_start();//démarre ou récupère une session

// if(!empty($_POST)){
//     $f_username = trim(filter_input(INPUT_POST, "uname", FILTER_SANITIZE_STRING));
//     $f_password = filter_input(INPUT_POST, "psw", FILTER_VALIDATE_REGEXP, [
//         "options" => array("regexp"=>'/[A-Za-z0-9]{6,32}/')
//     ]);
    
//     if($f_username && $f_password){
//         if($f_username === $user['uname'] && $f_password === $user['psw']){
//             $_SESSION['user'] = $user;
//             header("Location: bienvenue.php");
//         }
//         else header("Location: /?error=2");//identifiant incorrect
//     }
//     else header("Location:index.php"); // pirate
// }
// else header("Location: /?error=0");//champs obligatoire manquant
?> -->