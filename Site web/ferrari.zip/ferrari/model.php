<?php

// $user = [
//     'uname' => 'Nico', 
//     'psw' => 'pass1234'
// ];