<?php

$phrase = "Notre formation DL commence aujourd'hui";
echo "La phrase « $phrase » contient ".str_word_count($phrase)." mots"; // str_word_count() compte le nombre de mots dans une chaîne de caractères