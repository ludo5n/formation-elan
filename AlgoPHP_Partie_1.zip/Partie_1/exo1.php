<?php

$phrase = "Notre formation DL commence aujourd'hui";
$longueur = strlen($phrase); // strlen() compte le nombre de caractères
echo "La phrase « $phrase » contient ".strlen($phrase)." caractères";
echo "La phrase « $phrase » contient $longueur caractères";