<?php

$phrase = "Notre formation DL commence aujourd'hui";
echo $phrase."<br>";
echo str_replace("aujourd'hui","demain",$phrase);